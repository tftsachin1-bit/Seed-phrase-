let W=[];
const frac=x=>Math.floor((x-Math.floor(x))*4294967296)>>>0;
const K=[],H0=[];
for(let p=2,c=0;c<64;p++){let ok=1;for(let d=2;d*d<=p;d++)if(p%d===0){ok=0;break}
  if(ok){if(c<8)H0.push(frac(Math.sqrt(p)));K.push(frac(Math.cbrt(p)));c++}}
function sha256(b){
  const l=b.length,n=((l+9+63)>>6)<<6,m=new Uint8Array(n);
  m.set(b);m[l]=128;new DataView(m.buffer).setUint32(n-4,l*8);
  let h=H0.slice();
  for(let o=0;o<n;o+=64){
    const w=new Array(64),dv=new DataView(m.buffer,o,64);
    for(let i=0;i<16;i++)w[i]=dv.getUint32(i*4);
    for(let i=16;i<64;i++){const x=w[i-15],y=w[i-2];
      w[i]=(w[i-16]+((x>>>7|x<<25)^(x>>>18|x<<14)^(x>>>3))+w[i-7]+((y>>>17|y<<15)^(y>>>19|y<<13)^(y>>>10)))|0}
    let [a,b2,c,d,e,f,g,k]=h;
    for(let i=0;i<64;i++){
      const t1=(k+((e>>>6|e<<26)^(e>>>11|e<<21)^(e>>>25|e<<7))+((e&f)^(~e&g))+K[i]+w[i])|0;
      const t2=(((a>>>2|a<<30)^(a>>>13|a<<19)^(a>>>22|a<<10))+((a&b2)^(a&c)^(b2&c)))|0;
      k=g;g=f;f=e;e=(d+t1)|0;d=c;c=b2;b2=a;a=(t1+t2)|0}
    const r=[a,b2,c,d,e,f,g,k];h=h.map((x,i)=>(x+r[i])|0)}
  return h;
}
function makePhrase(n){
  const ent=n===12?16:32,b=new Uint8Array(ent);
  crypto.getRandomValues(b);
  let bits=[...b].map(x=>x.toString(2).padStart(8,"0")).join("");
  bits+=((sha256(b)[0]>>>24)&255).toString(2).padStart(8,"0").slice(0,ent/4);
  const out=[];
  for(let i=0;i<bits.length;i+=11)out.push(W[parseInt(bits.slice(i,i+11),2)]);
  return out;
}
const $=id=>document.getElementById(id);
let cur=[],count=0;
function show(){
  const g=$("grid");g.innerHTML="";
  cur.forEach((w,i)=>{const li=document.createElement("li");li.style.setProperty("--i",i);li.innerHTML="<i>"+(i+1)+"</i><b>"+w+"</b>";g.appendChild(li)});
  g.classList.toggle("hide",$("hide").checked);
  $("txt").value=cur.join(" ");$("txt").classList.toggle("hide",$("hide").checked);
  $("cnt").textContent=cur.length?"Phrase #"+count+" \u2713 Checked":"";explain();
}
function run(){
  if(!(window.crypto&&crypto.getRandomValues)){$("msg").textContent="Is browser mein secure random nahi hai. Chrome ya Firefox use karo.";return}
  let p,t=0;do{p=makePhrase(+$("len").value);t++}while(checkPhrase(p.join(" "))[0]!=="ok"&&t<10);
  if(checkPhrase(p.join(" "))[0]!=="ok"){$("msg").textContent="Phrase check fail hui, dobara try karo.";return}
  cur=p;count++;show();$("msg").textContent="Nayi phrase ban gayi aur checker se verify ho chuki hai.";
}
$("go").onclick=run;$("len").onchange=run;$("hide").onchange=show;
$("copy").onclick=async()=>{
  if(!cur.length){$("msg").textContent="Pehle phrase banao.";return}
  const t=cur.join(" ");
  try{await navigator.clipboard.writeText(t);$("msg").textContent="Copy ho gaya. Kaam ke baad clipboard saaf kar dena.";return}catch(e){}
  try{const a=$("txt");a.classList.remove("hide");a.focus();a.select();a.setSelectionRange(0,t.length);
    if(document.execCommand("copy")){$("msg").textContent="Copy ho gaya.";show();return}}catch(e){}
  $("msg").textContent="Auto-copy block hai. Neeche box ke text ko dabakar select karke copy karo.";
};
function toBits(ws){return ws.map(w=>W.indexOf(w).toString(2).padStart(11,"0")).join("")}
function csBits(bits,el){
  const by=new Uint8Array(el/8);for(let i=0;i<by.length;i++)by[i]=parseInt(bits.slice(i*8,i*8+8),2);
  return ((sha256(by)[0]>>>24)&255).toString(2).padStart(8,"0").slice(0,el/32);
}
function checkPhrase(str){
  const ws=str.toLowerCase().trim().split(/\s+/).filter(Boolean);
  if(!ws.length)return["bad","Pehle words daalo."];
  if(![12,15,18,21,24].includes(ws.length))return["bad","Words ki ginti "+ws.length+" hai. 12, 15, 18, 21 ya 24 words chahiye."];
  const unk=ws.filter(w=>W.indexOf(w)<0);
  if(unk.length)return["bad","Ye word list mein nahi hai: "+unk.slice(0,3).join(", ")+(unk.length>3?" ...":"")+". Spelling check karo."];
  const bits=toBits(ws),el=ws.length*11*32/33;
  if(csBits(bits,el)!==bits.slice(el))return["bad","Saare words list mein hain, par checksum galat hai. Ye valid phrase nahi hai (koi word galat ya order badla hua)."];
  return["ok","Valid BIP39 phrase hai. Ye tool sirf format check karta hai, wallet mein paisa hai ya nahi ye nahi batata."];
}
$("chkgo").onclick=()=>{const r=checkPhrase($("chk").value);const o=$("chkout");o.className=r[0];o.textContent=r[1]};
function explain(){
  if(!cur.length)return;
  const bits=toBits(cur),el=cur.length*11*32/33;
  let h='<div class="bits"><span class="ent">'+bits.slice(0,el).replace(/(.{8})/g,"$1 ").trim()+'</span> <span class="cs">'+bits.slice(el)+'</span></div>';
  h+='<p>1. Device ne '+el+' random bits banaye (upar normal text).<br>2. Unka SHA-256 liya, uske pehle '+(el/32)+' bits checksum bane (hare, bold).<br>3. Kul '+bits.length+' bits ko 11-11 ke tukdon mein baanta. Har tukda 0 se 2047 tak ek number hai, aur wahi list ka word hai.</p>';
  h+='<div class="tw"><table><tr><th>#</th><th>11 bits</th><th>No.</th><th>Word</th></tr>';
  cur.forEach((w,i)=>{const b=bits.slice(i*11,i*11+11);h+="<tr><td>"+(i+1)+"</td><td>"+b+"</td><td>"+parseInt(b,2)+"</td><td>"+w+"</td></tr>"});
  $("how").innerHTML=h+"</table></div>";
}
fetch("/wordlist.json",{cache:"no-store"}).then(r=>r.json()).then(j=>{
  if(!Array.isArray(j)||j.length!==2048)throw new Error("bad wordlist");
  W=j;run();
}).catch(()=>{$("msg").textContent="Wordlist load nahi hui. Server chal raha hai?"});

